/**
 * Clase ejecutable (main)
 */
public class LaboratorioEjecutable
{
    public static void main(String[] args){
        Laboratorio laboratorio1 = new Laboratorio("Colgate SA", "Junin 5204", "54-11-4239-8447", 200, 34);
        
        System.out.println(laboratorio1.mostrar());
    }
}