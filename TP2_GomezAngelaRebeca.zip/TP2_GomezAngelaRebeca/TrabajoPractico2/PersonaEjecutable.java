/**
 * Clase ejecutable (main)
 */
public class PersonaEjecutable
{
    public static void main(String[] args){
        Persona persona1 = new Persona(40047821, "Facundo", "Fernandez", 1996);
        
        persona1.mostrar();
    }
}